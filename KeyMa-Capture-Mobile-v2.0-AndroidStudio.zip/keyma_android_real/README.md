# KeyMa Capture Mobile v2.0

Gerçek Android Gradle projesidir. Android 8-15+ hedeflenmiştir (minSdk 23, targetSdk 35).

## Özellikler
- KeyMa Houzez paneli ile aynı oturum
- Uygulama içi Sahibinden / Emlakjet tarayıcısı
- Native geri / ileri / KeyMa / portal kısayolları
- v0.6.2 stabil Capture parser tabanı
- İlan detayında `KEYMA'YA AL`
- Telefon / WhatsApp bağlantılarını Android uygulamalarına yönlendirme
- Cookie / oturum kalıcılığı

## Build
JDK 17 + Android SDK 35 ile:

```bash
gradle :app:assembleDebug
```

Kurulabilir debug APK: `app/build/outputs/apk/debug/app-debug.apk`

Repo GitHub'a yüklendiğinde Actions > Build KeyMa Capture APK > Run workflow ile otomatik APK üretir.
