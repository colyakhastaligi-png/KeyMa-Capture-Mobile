package com.keyma.capture;

import android.app.Activity;
import android.os.Bundle;
import android.os.Message;
import android.graphics.Color;
import android.content.Intent;
import android.net.Uri;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import android.util.Base64;
import org.json.JSONTokener;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.net.URLEncoder;

public class MainActivity extends Activity {
    private static final String KEYMA_HOME = "https://keyma.com.tr/user-dashboard-2/?keyma_capture=1";
    private static final String SAHIBINDEN = "https://www.sahibinden.com/";
    private static final String EMLAKJET = "https://www.emlakjet.com/";
    private WebView web;
    private TextView status;
    private ProgressBar progress;
    private String captureScript;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        buildUi();
        configureWebView();
        captureScript = readAsset("capture.js");
        if (state == null) web.loadUrl(KEYMA_HOME);
        else web.restoreState(state);
    }

    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }

    private TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(color);
        t.setGravity(Gravity.CENTER_VERTICAL);
        t.setPadding(dp(12),0,dp(12),0);
        if (bold) t.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        return t;
    }

    private Button button(String s) {
        Button b = new Button(this);
        b.setText(s); b.setTextSize(11); b.setAllCaps(false);
        b.setTextColor(Color.WHITE); b.setBackgroundColor(Color.rgb(13,34,48));
        b.setPadding(dp(8),0,dp(8),0);
        return b;
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(7,19,29));

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(dp(8),dp(4),dp(8),dp(4));
        TextView brand = text("KM  KeyMa Capture", 16, Color.WHITE, true);
        top.addView(brand, new LinearLayout.LayoutParams(0,dp(48),1));
        status = text("Hazır", 10, Color.rgb(160,182,194), false);
        status.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);
        top.addView(status, new LinearLayout.LayoutParams(dp(120),dp(48)));
        root.addView(top,new LinearLayout.LayoutParams(-1,dp(56)));

        progress = new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);
        progress.setMax(100); progress.setProgress(0);
        root.addView(progress,new LinearLayout.LayoutParams(-1,dp(3)));

        web = new WebView(this);
        root.addView(web,new LinearLayout.LayoutParams(-1,0,1));

        LinearLayout nav = new LinearLayout(this);
        nav.setOrientation(LinearLayout.HORIZONTAL); nav.setGravity(Gravity.CENTER);
        nav.setPadding(dp(4),dp(4),dp(4),dp(4));
        Button back=button("‹ Geri"), fwd=button("İleri ›"), home=button("KeyMa"), s=button("Sahibinden"), e=button("Emlakjet"), cap=button("KEYMA’YA AL");
        cap.setTextColor(Color.rgb(7,19,29)); cap.setBackgroundColor(Color.rgb(217,255,53)); cap.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        View.OnClickListener[] dummy = new View.OnClickListener[0];
        back.setOnClickListener(v->{ if(web.canGoBack()) web.goBack(); });
        fwd.setOnClickListener(v->{ if(web.canGoForward()) web.goForward(); });
        home.setOnClickListener(v->web.loadUrl(KEYMA_HOME));
        s.setOnClickListener(v->web.loadUrl(SAHIBINDEN));
        e.setOnClickListener(v->web.loadUrl(EMLAKJET));
        cap.setOnClickListener(v->captureCurrentListing());
        Button[] bs={back,fwd,home,s,e};
        for(Button b:bs) nav.addView(b,new LinearLayout.LayoutParams(0,dp(48),1));
        nav.addView(cap,new LinearLayout.LayoutParams(0,dp(48),1.45f));
        root.addView(nav,new LinearLayout.LayoutParams(-1,dp(60)));
        setContentView(root);
    }

    private void configureWebView() {
        WebSettings ws = web.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setDatabaseEnabled(true);
        ws.setLoadsImagesAutomatically(true);
        ws.setUseWideViewPort(true);
        ws.setLoadWithOverviewMode(true);
        ws.setBuiltInZoomControls(true);
        ws.setDisplayZoomControls(false);
        ws.setJavaScriptCanOpenWindowsAutomatically(true);
        ws.setSupportMultipleWindows(true);
        ws.setUserAgentString(ws.getUserAgentString()+" KeyMaCapture/2.0");
        CookieManager cm=CookieManager.getInstance(); cm.setAcceptCookie(true); cm.setAcceptThirdPartyCookies(web,true);

        web.setWebViewClient(new WebViewClient(){
            @Override public boolean shouldOverrideUrlLoading(WebView view,String url){ return handleExternal(url); }
            @Override public void onPageFinished(WebView view,String url){
                status.setText(portalName(url));
                CookieManager.getInstance().flush();
            }
        });
        web.setWebChromeClient(new WebChromeClient(){
            @Override public void onProgressChanged(WebView view,int newProgress){ progress.setProgress(newProgress); progress.setVisibility(newProgress>=100?View.GONE:View.VISIBLE); }
            @Override public boolean onCreateWindow(WebView view,boolean isDialog,boolean isUserGesture,Message resultMsg){
                final WebView popup=new WebView(MainActivity.this);
                popup.getSettings().setJavaScriptEnabled(true);
                popup.setWebViewClient(new WebViewClient(){
                    @Override public boolean shouldOverrideUrlLoading(WebView v,String url){
                        popup.destroy();
                        if(!handleExternal(url)) web.loadUrl(url);
                        return true;
                    }
                });
                WebView.WebViewTransport transport=(WebView.WebViewTransport)resultMsg.obj;
                transport.setWebView(popup); resultMsg.sendToTarget(); return true;
            }
        });
    }

    private boolean handleExternal(String url){
        if(url==null)return false;
        Uri u=Uri.parse(url); String scheme=u.getScheme()==null?"":u.getScheme().toLowerCase();
        String host=u.getHost()==null?"":u.getHost().toLowerCase();
        boolean external=scheme.equals("tel")||scheme.equals("mailto")||scheme.equals("sms")||scheme.equals("whatsapp")||scheme.equals("intent")||scheme.equals("market")||host.equals("wa.me")||host.contains("whatsapp.com");
        if(!external)return false;
        try{ startActivity(new Intent(Intent.ACTION_VIEW,u)); }
        catch(Exception ex){ Toast.makeText(this,"Bağlantı açılamadı",Toast.LENGTH_SHORT).show(); }
        return true;
    }

    private String portalName(String url){
        if(url==null)return "Hazır";
        if(url.contains("sahibinden.com"))return "Sahibinden";
        if(url.contains("emlakjet.com"))return "Emlakjet";
        if(url.contains("keyma.com.tr"))return "KeyMa";
        return "Tarayıcı";
    }

    private void captureCurrentListing(){
        String url=web.getUrl();
        if(url==null || !(url.contains("sahibinden.com")||url.contains("emlakjet.com"))){
            Toast.makeText(this,"Önce Sahibinden veya Emlakjet ilan detayını açın.",Toast.LENGTH_LONG).show(); return;
        }
        if(captureScript==null||captureScript.isEmpty()){
            Toast.makeText(this,"Capture motoru yüklenemedi.",Toast.LENGTH_LONG).show(); return;
        }
        status.setText("Okunuyor…");
        web.evaluateJavascript(captureScript, value->{
            try{
                Object parsed=new JSONTokener(value).nextValue();
                String json=parsed==null?"":parsed.toString();
                if(json.isEmpty()||json.equals("null")||json.equals("{}")) throw new Exception("İlan verisi bulunamadı");
                String b64=Base64.encodeToString(json.getBytes(StandardCharsets.UTF_8),Base64.NO_WRAP);
                String enc=URLEncoder.encode(b64,"UTF-8");
                Toast.makeText(this,"İlan okundu · KeyMa'ya aktarılıyor",Toast.LENGTH_SHORT).show();
                web.loadUrl(KEYMA_HOME+"#kma_mobile_capture="+enc);
            }catch(Exception ex){
                status.setText("Capture hatası");
                Toast.makeText(this,"İlan okunamadı: "+ex.getMessage(),Toast.LENGTH_LONG).show();
            }
        });
    }

    private String readAsset(String name){
        try(BufferedReader br=new BufferedReader(new InputStreamReader(getAssets().open(name),StandardCharsets.UTF_8))){
            StringBuilder sb=new StringBuilder(); String line; while((line=br.readLine())!=null)sb.append(line).append('\n'); return sb.toString();
        }catch(Exception e){ return ""; }
    }

    @Override protected void onSaveInstanceState(Bundle out){ web.saveState(out); super.onSaveInstanceState(out); }
    @Override public void onBackPressed(){ if(web!=null&&web.canGoBack())web.goBack(); else super.onBackPressed(); }
    @Override protected void onDestroy(){ if(web!=null){ web.stopLoading(); web.destroy(); } super.onDestroy(); }
}
