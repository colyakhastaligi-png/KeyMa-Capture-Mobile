(()=>{'use strict';
const $=(s,r=document)=>r.querySelector(s),$$=(s,r=document)=>Array.from(r.querySelectorAll(s));
const clean=s=>String(s||'').replace(/\u00a0/g,' ').replace(/\s+/g,' ').trim();
const trLower=s=>clean(s).toLocaleLowerCase('tr-TR');
const visible=el=>{if(!el)return false;const s=getComputedStyle(el),r=el.getBoundingClientRect();return s.display!=='none'&&s.visibility!=='hidden'&&Number(s.opacity)!==0&&r.width>0&&r.height>0};
const text=el=>el&&visible(el)?clean(el.innerText||el.textContent):'';
const texts=(sels,root=document)=>{for(const s of sels){const vals=$$(s,root).map(text).filter(Boolean);if(vals.length)return vals}return[]};
const firstText=(sels,root=document)=>texts(sels,root)[0]||'';
const meta=(n,p='property')=>document.querySelector(`meta[${p}="${n}"]`)?.content||'';
const bodyLines=()=>String(document.body?.innerText||'').split(/\n+/).map(clean).filter(Boolean).slice(0,12000);
const bodyText=()=>bodyLines().join('\n').slice(0,220000);
function jsonLd(){const out=[];$$('script[type="application/ld+json"]').forEach(s=>{try{let x=JSON.parse(s.textContent);if(Array.isArray(x))out.push(...x);else if(x&&Array.isArray(x['@graph']))out.push(...x['@graph']);else if(x)out.push(x)}catch(e){}});return out}
function priceNum(v){v=String(v||'').replace(/[^0-9.,]/g,'');if(!v)return 0;v=v.replace(/\.(?=\d{3}(?:\D|$))/g,'').replace(/,(?=\d{3}(?:\D|$))/g,'').replace(',','.');const n=parseFloat(v);return Number.isFinite(n)?n:0}
function normPhone(v){const m=String(v||'').match(/(?:\+?90\s*)?0?5\d{2}[\s().-]*\d{3}[\s.-]*\d{2}[\s.-]*\d{2}/);return m?clean(m[0]):''}
function findPhone(){const vals=[];$$('a[href^="tel:"]').filter(visible).forEach(a=>vals.push(a.getAttribute('href').replace(/^tel:/i,''),text(a)));$$('[class*="phone" i],[data-testid*="phone" i],[id*="phone" i],[aria-label*="telefon" i]').filter(visible).forEach(e=>vals.push(text(e),e.getAttribute('aria-label')||''));for(const v of vals){const p=normPhone(v);if(p)return p}return''}
function keyMapGeneric(){const map={};
  const add=(k,v)=>{k=clean(k).replace(/:$/,'');v=clean(v);if(k&&v&&k.length<80&&!map[k])map[k]=v};
  $$('li').forEach(li=>{const k=firstText(['strong','b','label','dt'],li),v=firstText(['span','dd'],li)||clean(li.textContent).replace(k,'');if(k&&v)add(k,v)});
  $$('dl').forEach(dl=>{const dts=$$('dt',dl),dds=$$('dd',dl);dts.forEach((dt,i)=>add(text(dt),text(dds[i])))});
  $$('table tr').forEach(tr=>{const cells=$$('th,td',tr).map(text).filter(Boolean);if(cells.length>=2)add(cells[0],cells.slice(1).join(' '))});
  const lines=bodyLines();for(let i=0;i<lines.length-1;i++){const k=lines[i],v=lines[i+1];if(/^(İlan (No|Numarası|Tarihi|Güncelleme Tarihi)|Kategori|Emlak Tipi|Kimden|Oda Sayısı|Banyo Sayısı|Bulunduğu Kat|Kat Sayısı|Brüt|Net|Brüt M²|Net M²|Metrekare|m²|Ada|Parsel|Site İçerisinde|Kullanım Durumu)$/i.test(k))add(k,v)}
  return map;
}
const val=(map,keys)=>{for(const key of keys){const hit=Object.keys(map).find(k=>trLower(k)===trLower(key));if(hit&&map[hit])return map[hit]}return''};
function inferType(raw,map={}){const cat=clean(val(map,['Kategori','Emlak Tipi'])||raw);const t=trLower(cat+' '+raw);
  let transaction='';if(/kat karşılığı|kat karsiligi/.test(t))transaction='kat_karsiligi';else if(/kiralık|kiralik|devren kiralık|devren kiralik/.test(t))transaction='kiralik';else if(/satılık|satilik/.test(t))transaction='satilik';
  let category='',subtype='';
  if(/arsa|tarla|bahçe|bahce|bağ|bag\b|zeytinlik|arsa payı|arsa payi/.test(t)){category='arsa';subtype=/tarla/.test(t)?'Tarla':/bahçe|bahce/.test(t)?'Bahçe':'Arsa'}
  else if(/fabrika|depo|imalathane|atölye|atolye|antrepo/.test(t)){category='fabrika';subtype=/fabrika/.test(t)?'Fabrika':/depo/.test(t)?'Depo':'Endüstriyel'}
  else if(/dükkan|dukkan|ofis|işyeri|isyeri|mağaza|magaza|plaza|büro|buro|ticari|akaryakıt|akaryakit|otel|pansiyon/.test(t)){category='ticari';subtype=/dükkan|dukkan/.test(t)?'Dükkan':/ofis|büro|buro/.test(t)?'Ofis':/otel/.test(t)?'Otel':'Ticari'}
  else if(/villa/.test(t)){category='konut';subtype='Villa'}
  else if(/müstakil|mustakil/.test(t)){category='konut';subtype='Müstakil Ev'}
  else if(/rezidans/.test(t)){category='konut';subtype='Rezidans'}
  else if(/daire|konut|apartman/.test(t)){category='konut';subtype='Daire'}
  return{transaction,category,subtype:subtype||clean(cat.replace(/^(Satılık|Kiralık)\s+/i,''))};
}
function extractOwnerFromLines(lines){
  for(let i=0;i<lines.length;i++){
    if(/MÜLK SAHİBİ/i.test(lines[i])){
      let same=clean(lines[i].replace(/MÜLK SAHİBİ/ig,''));if(same&&same.length<80)return same;
      for(let j=i-1;j>=Math.max(0,i-4);j--){const c=lines[j];if(c&&c.length<80&&!/Ara|Mesaj|İlan|Fiyat|Doğrulama/i.test(c))return c}
    }
  }
  return'';
}
function descriptionByHeading(lines){const idx=lines.findIndex(x=>/Açıklaması$|^Açıklama$/i.test(x));if(idx<0)return'';const out=[];for(let i=idx+1;i<Math.min(lines.length,idx+80);i++){if(/^(Konum Bilgisi|Fiyat Değişimi|Semt Özellikleri|Benzer İlanlar|MÜLK SAHİBİ|Ara|Mesaj Gönder)$/i.test(lines[i]))break;out.push(lines[i])}return clean(out.join(' ')).slice(0,8000)}
function getImages(){const arr=[];const push=u=>{u=String(u||'');if(/^https?:/i.test(u)&&!arr.includes(u))arr.push(u)};push(meta('og:image'));$$('img').filter(visible).forEach(i=>{const u=i.currentSrc||i.src;if((i.naturalWidth>=420&&i.naturalHeight>=260)||/stdImg|classified|gallery|listing|photo/i.test(i.className||''))push(u)});return arr.slice(0,24)}
function breadcrumbs(){return $$('nav a,[class*="breadcrumb" i] a,[aria-label*="breadcrumb" i] a').filter(visible).map(text).filter(Boolean)}
function portalSahibinden(){const map=keyMapGeneric(),lines=bodyLines(),all=lines.join(' ');const locLinks=texts(['.classifiedInfo h2 a','.classifiedInfo [class*="location" i] a','.classifiedDetailTitle + * a']);
  const title=firstText(['.classifiedDetailTitle h1','.classifiedDetailTitle','h1'])||meta('og:title');
  const price=priceNum(firstText(['.classified-price-wrapper','.classifiedInfo h3','[itemprop="price"]'])||meta('product:price:amount')||meta('og:price:amount'));
  const type=inferType([title,val(map,['Emlak Tipi','Kategori']),location.pathname].join(' '),map);
  const b=breadcrumbs();let city='',district='',neighborhood='';if(locLinks.length>=3){city=locLinks[0];district=locLinks[1];neighborhood=locLinks[2]}else if(b.length>=3){const tail=b.slice(-3);city=tail[0];district=tail[1];neighborhood=tail[2]}
  const owner=firstText(['.classifiedUserContent .username-info-area h5','.classifiedUserContent h5','.username-info-area h5','.user-info-agent h3','[class*="seller" i] [class*="name" i]'])||extractOwnerFromLines(lines)||val(map,['İlan Sahibi','İlanı Veren','Yetkili']);
  const kimden=val(map,['Kimden','İlanı Veren']);const fsbo=/sahibinden|mülk sahibi/i.test(kimden+' '+all.slice(-25000));
  const ext=clean(val(map,['İlan No','İlan Numarası']))||((location.pathname.match(/-(\d{6,})(?:\/detay)?\/?$/)||[])[1]||'');
  const desc=firstText(['.classifiedDescription','.uiBoxContainer.classifiedDescription','[itemprop="description"]'])||descriptionByHeading(lines)||meta('description','name');
  return{source:'Sahibinden',external_id:ext,title:clean(title),price,owner_name:clean(owner),owner_phone:findPhone(),transaction_type:type.transaction,category:type.category,subtype:type.subtype,city:clean(city),district:clean(district),neighborhood:clean(neighborhood),rooms:clean(val(map,['Oda Sayısı','Oda'])),sqm:priceNum(val(map,['m² (Brüt)','Brüt m²','Brüt M²','Metrekare','m²'])),net_sqm:priceNum(val(map,['m² (Net)','Net m²','Net M²','Net'])),floor:val(map,['Bulunduğu Kat']),listing_date:val(map,['İlan Tarihi','İlan Güncelleme Tarihi']),fsbo,description:clean(desc).slice(0,8000),raw_features:map,images:getImages()};
}
function portalEmlakjet(){const map=keyMapGeneric(),lines=bodyLines(),all=lines.join(' ');const title=firstText(['h1','[data-testid*="title" i]','[class*="listing" i] h1'])||meta('og:title');
  let price=priceNum(firstText(['[data-testid*="price" i]','[class*="price" i]','[itemprop="price"]'])||meta('product:price:amount'));if(!price){const line=lines.find(x=>/^\d[\d. ,]+\s*₺$/.test(x));price=priceNum(line)}
  const type=inferType([title,val(map,['Kategori','Emlak Tipi']),location.pathname].join(' '),map);let city='',district='',neighborhood='';const locationLine=lines.find(x=>/Mahallesi.*,.*,.*/i.test(x)&&!/İlan/i.test(x));if(locationLine){const parts=locationLine.replace(/\s*-\s*Haritada Gör.*$/i,'').split(',').map(clean);if(parts.length>=3){neighborhood=parts[0];district=parts[1];city=parts[2]}}
  const b=breadcrumbs();if((!city||!district)&&b.length>=3){const tail=b.slice(-4);for(const x of tail){if(/Mahallesi/i.test(x))neighborhood=neighborhood||x;else if(/Diyarbakır|İstanbul|Ankara|İzmir|Mersin|Antalya|Bursa|Adana|Gaziantep|Şanlıurfa/i.test(x))city=city||x}}
  let owner=firstText(['[data-testid*="seller" i] [class*="name" i]','[class*="seller" i] [class*="name" i]','.user-info-agent h3','[class*="owner" i] [class*="name" i]']);owner=owner||extractOwnerFromLines(lines);
  const fsbo=/MÜLK SAHİBİ/i.test(all)||/Sahibinden/.test(title)||/Sahibinden/.test(val(map,['Kimden']));
  const ext=clean(val(map,['İlan Numarası','İlan No','İlan ID']))||((location.pathname.match(/-(\d{6,})\/?$/)||[])[1]||'');
  const desc=firstText(['[data-testid*="description" i]','[class*="description" i]','[itemprop="description"]'])||descriptionByHeading(lines)||meta('description','name');
  return{source:'Emlakjet',external_id:ext,title:clean(title),price,owner_name:clean(owner),owner_phone:findPhone(),transaction_type:type.transaction,category:type.category,subtype:type.subtype,city:clean(city),district:clean(district),neighborhood:clean(neighborhood),rooms:clean(val(map,['Oda Sayısı','Oda'])),sqm:priceNum(val(map,['Brüt','Brüt m²','Brüt M²','Metrekare'])),net_sqm:priceNum(val(map,['Net','Net m²','Net M²'])),floor:val(map,['Bulunduğu Kat']),listing_date:val(map,['İlan Güncelleme Tarihi','İlan Tarihi']),fsbo,description:clean(desc).slice(0,8000),raw_features:map,images:getImages()};
}
function generic(){const map=keyMapGeneric(),lines=bodyLines(),ld=jsonLd(),raw=document.title+' '+location.pathname+' '+lines.slice(0,250).join(' '),type=inferType(raw,map);let title=meta('og:title')||firstText(['h1']);let price=0;for(const x of ld){price=price||priceNum(x?.offers?.price||x?.price)}price=price||priceNum(firstText(['[itemprop="price"]','[class*="price" i]']));return{source:location.hostname,external_id:val(map,['İlan No','İlan Numarası']),title:clean(title),price,owner_name:extractOwnerFromLines(lines),owner_phone:findPhone(),transaction_type:type.transaction,category:type.category,subtype:type.subtype,city:'',district:'',neighborhood:'',rooms:val(map,['Oda Sayısı']),sqm:priceNum(val(map,['Brüt','Brüt M²','Metrekare'])),net_sqm:priceNum(val(map,['Net','Net M²'])),floor:val(map,['Bulunduğu Kat']),listing_date:val(map,['İlan Tarihi','İlan Güncelleme Tarihi']),fsbo:/sahibinden|mülk sahibi/i.test(raw),description:descriptionByHeading(lines)||meta('description','name'),raw_features:map,images:getImages()}}
function miniSummary(x){const loc=[x.neighborhood,x.district].filter(Boolean).join(' / ');const kind=[x.transaction_type==='satilik'?'Satılık':x.transaction_type==='kiralik'?'Kiralık':x.transaction_type==='kat_karsiligi'?'Kat Karşılığı':'',x.rooms,x.subtype||x.category].filter(Boolean).join(' ');const parts=[loc,kind,x.sqm?`${x.sqm} m²`:'',x.price?new Intl.NumberFormat('tr-TR').format(x.price)+' TL':''].filter(Boolean);return parts.join(' · ')}
function isDetail(x){const h=location.hostname,p=location.pathname,t=bodyText().slice(0,70000);if(h.includes('sahibinden.com'))return /\/ilan\//i.test(p)&&(/\/detay\/?$/i.test(p)||!!$('.classifiedDetailTitle')||/İlan No/i.test(t));if(h.includes('emlakjet.com'))return /\/ilan\//i.test(p)&&!!x.external_id&&!!x.title;return !!x.external_id&&!!x.title}
function collect(){let x;if(location.hostname.includes('sahibinden.com'))x=portalSahibinden();else if(location.hostname.includes('emlakjet.com'))x=portalEmlakjet();else x=generic();x.source_url=location.href.split('#')[0];x.currency='TRY';x.portal_state='active';x.cover_image=x.images?.[0]||'';x.captured_at=new Date().toISOString();x.portfolio_summary=miniSummary(x);x.is_detail=isDetail(x);return x}

try{return JSON.stringify(collect());}catch(e){return JSON.stringify({error:String(e&&e.message||e)});}
})()